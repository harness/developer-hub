#!/usr/bin/env python3
"""
Split.io Bulk Identities Upload Tool

Uploads identities and their attributes to Split.io from a CSV file.

Usage:
    python3 scripts/split_bulk_identities.py \
        --csv identities.csv \
        --config config/split_identities.json \
        [--batch-size 1000] \
        [--dry-run]

CSV Format:
    key,attr1,attr2,attr3
    user_123,premium,USA,2024-01-15
    user_456,free,Canada,2024-02-01

Config Format (JSON):
    {
      "api_base_url": "https://api.split.io/internal/api/v2",
      "traffic_type_id": "user",
      "environment_id": "your-env-id",
      "admin_api_key": "your-api-key",
      "attribute_mapping": {
        "attr1": "plan_type",
        "attr2": "country",
        "attr3": "signup_date"
      }
    }
"""

import argparse
import csv
import json
import sys
from typing import Dict, List, Any
import requests


def load_config(config_path: str) -> Dict[str, Any]:
    """Load configuration from JSON file."""
    try:
        with open(config_path, 'r') as f:
            return json.load(f)
    except FileNotFoundError:
        print(f"❌ Config file not found: {config_path}")
        sys.exit(1)
    except json.JSONDecodeError as e:
        print(f"❌ Invalid JSON in config file: {e}")
        sys.exit(1)


def load_csv(csv_path: str) -> List[Dict[str, str]]:
    """Load CSV file and return list of row dictionaries."""
    try:
        with open(csv_path, 'r') as f:
            reader = csv.DictReader(f)
            return list(reader)
    except FileNotFoundError:
        print(f"❌ CSV file not found: {csv_path}")
        sys.exit(1)
    except Exception as e:
        print(f"❌ Error reading CSV: {e}")
        sys.exit(1)


def validate_config(config: Dict[str, Any]) -> None:
    """Validate required config fields."""
    required_fields = [
        'api_base_url',
        'traffic_type_id',
        'environment_id',
        'admin_api_key',
        'attribute_mapping'
    ]

    missing = [field for field in required_fields if field not in config]
    if missing:
        print(f"❌ Missing required config fields: {', '.join(missing)}")
        sys.exit(1)

    if not isinstance(config['attribute_mapping'], dict):
        print("❌ 'attribute_mapping' must be a JSON object")
        sys.exit(1)


def transform_row_to_identity(row: Dict[str, str], attribute_mapping: Dict[str, str]) -> Dict[str, Any]:
    """Transform CSV row to Split identity format."""
    if 'key' not in row:
        raise ValueError("CSV must have a 'key' column")

    identity = {
        "key": row['key'],
        "values": {}
    }

    # Map CSV columns to Split attribute IDs
    for csv_column, attribute_id in attribute_mapping.items():
        if csv_column in row and row[csv_column]:  # Only include non-empty values
            identity['values'][attribute_id] = row[csv_column]

    return identity


def chunk_list(items: List[Any], chunk_size: int) -> List[List[Any]]:
    """Split list into chunks of specified size."""
    return [items[i:i + chunk_size] for i in range(0, len(items), chunk_size)]


def upload_identities_batch(
    identities: List[Dict[str, Any]],
    config: Dict[str, Any],
    dry_run: bool = False
) -> bool:
    """Upload a batch of identities to Split API (bulk endpoint - OVERWRITES all attributes)."""
    url = (
        f"{config['api_base_url']}/trafficTypes/{config['traffic_type_id']}"
        f"/environments/{config['environment_id']}/identities"
    )

    headers = {
        'Authorization': f"Bearer {config['admin_api_key']}",
        'Content-Type': 'application/json'
    }

    if dry_run:
        print(f"\n🔍 DRY RUN - Would POST to: {url}")
        print(f"📦 Payload sample (first 2 identities):")
        print(json.dumps(identities[:2], indent=2))
        print(f"⚠️  BULK MODE: Will OVERWRITE all attributes for each key (deletes unspecified attributes)")
        return True

    try:
        response = requests.post(url, headers=headers, json=identities, timeout=30)
        response.raise_for_status()
        print(f"✅ Successfully uploaded {len(identities)} identities")
        return True
    except requests.exceptions.HTTPError as e:
        print(f"❌ HTTP Error: {e}")
        if response.text:
            print(f"   Response: {response.text}")
        return False
    except requests.exceptions.RequestException as e:
        print(f"❌ Request failed: {e}")
        return False


def upload_identity_patch(
    identity: Dict[str, Any],
    config: Dict[str, Any],
    dry_run: bool = False
) -> bool:
    """Upload a single identity using PATCH endpoint (preserves unspecified attributes)."""
    key = identity['key']
    url = (
        f"{config['api_base_url']}/trafficTypes/{config['traffic_type_id']}"
        f"/environments/{config['environment_id']}/identities/{key}"
    )

    headers = {
        'Authorization': f"Bearer {config['admin_api_key']}",
        'Content-Type': 'application/json'
    }

    # Payload is just the values, not the key
    payload = {"values": identity['values']}

    if dry_run:
        return True  # Don't print for every identity in dry-run, too verbose

    try:
        response = requests.put(url, headers=headers, json=payload, timeout=30)
        response.raise_for_status()
        return True
    except requests.exceptions.HTTPError as e:
        print(f"❌ HTTP Error for key '{key}': {e}")
        if response.text:
            print(f"   Response: {response.text}")
        return False
    except requests.exceptions.RequestException as e:
        print(f"❌ Request failed for key '{key}': {e}")
        return False


def main():
    parser = argparse.ArgumentParser(
        description='Upload identities to Split.io from CSV',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__
    )
    parser.add_argument(
        '--csv',
        required=True,
        help='Path to CSV file with identity data'
    )
    parser.add_argument(
        '--config',
        required=True,
        help='Path to JSON config file'
    )
    parser.add_argument(
        '--batch-size',
        type=int,
        default=1000,
        help='Number of identities per API call (default: 1000)'
    )
    parser.add_argument(
        '--dry-run',
        action='store_true',
        help='Preview what would be uploaded without making API calls'
    )
    parser.add_argument(
        '--patch-mode',
        action='store_true',
        help='Use PATCH endpoint (updates only provided attributes, preserves others). Default: bulk POST (overwrites all attributes)'
    )

    args = parser.parse_args()

    # Load config
    print(f"📖 Loading config from: {args.config}")
    config = load_config(args.config)
    validate_config(config)

    # Load CSV
    print(f"📖 Loading CSV from: {args.csv}")
    rows = load_csv(args.csv)
    print(f"📊 Found {len(rows)} rows in CSV")

    if not rows:
        print("⚠️  No rows to process")
        sys.exit(0)

    # Transform rows to identities
    print("🔄 Transforming CSV rows to Split identities...")
    identities = []
    errors = []

    for i, row in enumerate(rows, start=1):
        try:
            identity = transform_row_to_identity(row, config['attribute_mapping'])
            identities.append(identity)
        except Exception as e:
            errors.append(f"Row {i}: {e}")

    if errors:
        print(f"\n⚠️  {len(errors)} row(s) had errors:")
        for error in errors[:10]:  # Show first 10 errors
            print(f"   {error}")
        if len(errors) > 10:
            print(f"   ... and {len(errors) - 10} more")

    if not identities:
        print("❌ No valid identities to upload")
        sys.exit(1)

    print(f"✅ Successfully transformed {len(identities)} identities")

    # Upload based on mode
    if args.patch_mode:
        # PATCH mode: one PUT request per identity (preserves unspecified attributes)
        print(f"\n📤 PATCH MODE: Uploading {len(identities)} identities individually...")
        print("   ℹ️  Only provided attributes will be updated, existing attributes preserved")

        if args.dry_run:
            print("\n🔍 DRY RUN MODE - No actual uploads will be performed")
            print(f"\n🔍 Would PUT each identity to: .../identities/{{key}}")
            print(f"📦 Example payload for key '{identities[0]['key']}':")
            print(json.dumps({"values": identities[0]['values']}, indent=2))
            print(f"⚠️  PATCH MODE: Will preserve existing attributes not in CSV")
            success_count = len(identities)
            failure_count = 0
        else:
            success_count = 0
            failure_count = 0

            for i, identity in enumerate(identities, start=1):
                if i % 100 == 0 or i == 1:  # Progress every 100 identities
                    print(f"   Progress: {i}/{len(identities)}...")

                if upload_identity_patch(identity, config, dry_run=args.dry_run):
                    success_count += 1
                else:
                    failure_count += 1

            print(f"✅ Completed: {success_count} successful, {failure_count} failed")
    else:
        # BULK mode: batched POST requests (OVERWRITES all attributes)
        batches = chunk_list(identities, args.batch_size)
        print(f"\n📤 BULK MODE: Uploading {len(identities)} identities in {len(batches)} batch(es)...")
        print("   ⚠️  WARNING: Will OVERWRITE all attributes for each key (deletes unspecified attributes)")

        if args.dry_run:
            print("\n🔍 DRY RUN MODE - No actual uploads will be performed\n")

        success_count = 0
        failure_count = 0

        for i, batch in enumerate(batches, start=1):
            print(f"\n📦 Batch {i}/{len(batches)} ({len(batch)} identities)...")
            if upload_identities_batch(batch, config, dry_run=args.dry_run):
                success_count += len(batch)
            else:
                failure_count += len(batch)

    # Summary
    print("\n" + "="*60)
    print("📊 UPLOAD SUMMARY")
    print("="*60)
    print(f"Total rows in CSV:       {len(rows)}")
    print(f"Valid identities:        {len(identities)}")
    print(f"Transformation errors:   {len(errors)}")
    print(f"Successfully uploaded:   {success_count}")
    print(f"Failed to upload:        {failure_count}")

    if args.dry_run:
        print("\n🔍 This was a DRY RUN - no data was actually uploaded")

    if failure_count > 0:
        sys.exit(1)


if __name__ == '__main__':
    main()
