# FME Bulk Identities Upload Tool

Upload identities and their attributes to FME (Feature Management & Experimentation) from a CSV file.

## Overview

This tool reads a CSV file containing identity keys and attribute values, maps them to FME attribute IDs, and uploads them using the FME Admin API.

**Two Upload Modes:**

1. **Bulk Mode (default)** - Fast batch uploads that **OVERWRITE all attributes**
   - API: `POST .../identities` (array of identities)
   - ⚠️ **Replaces ALL attributes** for each key (deletes unspecified attributes)
   - Use when: Loading complete identity records, initial data import

2. **Patch Mode** (`--patch-mode`) - Individual updates that **preserve existing attributes**
   - API: `PUT .../identities/{key}` (one call per identity)
   - ✅ **Updates only provided attributes**, leaves others unchanged
   - Use when: Updating specific attributes without affecting others

## Prerequisites

1. **Python 3.8+** installed
2. **FME Admin API Key** with permissions to manage identities
3. **Traffic Type ID** and **Environment ID** from your FME workspace
4. **Attribute IDs** pre-configured in FME (this tool does NOT create attributes, only populates values)

## Installation

Install required Python package:

```bash
pip3 install requests
```

## Setup

### 1. Create Your Config File

Copy the example config and fill in your details:

```bash
cp scripts/fme_identities_utils/fme_identities_config.example.json config/fme_identities.json
```

Edit `config/fme_identities.json`:

```json
{
  "api_base_url": "https://api.split.io/internal/api/v2",
  "traffic_type_id": "user",
  "environment_id": "abc123-def456-ghi789",
  "admin_api_key": "your-admin-api-key-here",
  "attribute_mapping": {
    "plan": "plan_type",
    "company": "company_name",
    "pin": "org_pin",
    "signup": "signup_date"
  }
}
```

**Field descriptions:**
- `api_base_url` - Split API base URL (usually don't change)
- `traffic_type_id` - Your traffic type (e.g., "user", "account")
- `environment_id` - Target environment ID (find in FME Settings)
- `admin_api_key` - Admin API key from Split settings
- `attribute_mapping` - Maps CSV column names to Split attribute IDs

**⚠️ IMPORTANT:** Add `config/fme_identities.json` to `.gitignore` to protect your API key!

### 2. Prepare Your CSV File

Create a CSV with your identity data. **First column must be "key"**.

Example (`identities.csv`):

```csv
key,plan,company,pin,signup
user_001,premium,Acme Corp,1234,2024-01-15
user_002,free,Widget Inc,5678,2024-02-01
user_003,enterprise,TechCo,9012,2024-03-10
```

**CSV Requirements:**
- First column **must** be named `key` (the identity key for `getTreatment()` calls)
- Other columns map to attribute IDs via `attribute_mapping` in config
- Column names must match keys in `attribute_mapping`
- Empty values are skipped (won't overwrite existing values)

### 3. Verify Attributes Exist in FME

Before running, ensure all attribute IDs in your config exist in FME:

1. Go to FME Settings > Projects > View > Traffic Types > View / Edit attributes
2. Verify each attribute ID (e.g., `plan_type`, `company_name`, `org_pin`)
3. Note the exact attribute ID (case-sensitive!)

**The tool does NOT create attributes - they must already exist.**

## Which Mode Should I Use?

### Use Bulk Mode (default) when:
- ✅ Doing initial data load (no existing attributes to preserve)
- ✅ Your CSV contains ALL attributes for each identity
- ✅ You want to ensure identities match CSV exactly (clean slate)
- ✅ You need maximum speed (batched API calls)

**Example:** Loading user profiles from your database export where CSV has complete records.

### Use Patch Mode (`--patch-mode`) when:
- ✅ Updating a subset of attributes (e.g., just email and country)
- ✅ Identities already have attributes you want to keep
- ✅ You're incrementally adding new attributes
- ✅ You want to avoid accidentally deleting existing data

**Example:** Updating just the "account_tier" attribute for users without affecting their existing "country", "signup_date", etc.

### ⚠️ Important: Bulk Mode Overwrites

**Bulk mode replaces ALL attributes.** If an identity has existing attributes not in your CSV, they will be **deleted**.

**Example of data loss with bulk mode:**

Existing in Split:
```json
{
  "key": "user_001",
  "values": {
    "company_name": "Acme Corp",
    "org_pin": "1234",
    "plan_type": "premium"
  }
}
```

CSV with only plan update:
```csv
key,plan
user_001,enterprise
```

After bulk upload:
```json
{
  "key": "user_001",
  "values": {
    "plan_type": "enterprise"
    // ❌ company_name and org_pin DELETED
  }
}
```

After patch upload:
```json
{
  "key": "user_001",
  "values": {
    "company_name": "Acme Corp",  // ✅ preserved
    "org_pin": "1234",             // ✅ preserved
    "plan_type": "enterprise"      // ✅ updated
  }
}
```

---

## Usage

### Dry Run (Preview Only)

Test the tool without uploading:

```bash
python3 scripts/fme_identities_utils/fme_bulk_identities.py \
    --csv identities.csv \
    --config config/fme_identities.json \
    --dry-run
```

This shows:
- How many rows will be processed
- Sample of the JSON payload
- Any transformation errors

### Upload Identities (Bulk Mode - Overwrites All Attributes)

Remove `--dry-run` to actually upload:

```bash
python3 scripts/fme_identities_utils/fme_bulk_identities.py \
    --csv identities.csv \
    --config config/fme_identities.json
```

⚠️ **WARNING:** This OVERWRITES all attributes. Unspecified attributes will be deleted!

### Upload Identities (Patch Mode - Preserves Existing Attributes)

Use `--patch-mode` to update only specified attributes:

```bash
python3 scripts/fme_identities_utils/fme_bulk_identities.py \
    --csv identities.csv \
    --config config/fme_identities.json \
    --patch-mode
```

✅ **SAFE:** Only updates attributes in CSV, preserves all others.

**Trade-off:** Slower (one API call per identity) but safer.

### Custom Batch Size (Bulk Mode Only)

Control how many identities per API call (default: 1000):

```bash
python3 scripts/fme_identities_utils/fme_bulk_identities.py \
    --csv identities.csv \
    --config config/fme_identities.json \
    --batch-size 500
```

**Note:** `--batch-size` is ignored in `--patch-mode` (always one identity per request).

## Example Workflow

### Step 1: Create Config

```bash
cat > config/fme_identities.json <<EOF
{
  "api_base_url": "https://api.split.io/internal/api/v2",
  "traffic_type_id": "user",
  "environment_id": "prod-environment-id",
  "admin_api_key": "sk_admin_abc123...",
  "attribute_mapping": {
    "company": "company_name",
    "pin": "org_pin",
    "tier": "account_tier"
  }
}
EOF
```

### Step 2: Prepare CSV

```bash
cat > my_identities.csv <<EOF
key,company,pin,tier
alice@example.com,Acme Corp,1234,premium
bob@example.com,Widget Inc,5678,free
charlie@example.com,TechCo,9012,enterprise
EOF
```

### Step 3: Test with Dry Run

```bash
python3 scripts/fme_identities_utils/fme_bulk_identities.py \
    --csv my_identities.csv \
    --config config/fme_identities.json \
    --dry-run
```

**Expected output:**
```
📖 Loading config from: config/fme_identities.json
📖 Loading CSV from: my_identities.csv
📊 Found 3 rows in CSV
🔄 Transforming CSV rows to Split identities...
✅ Successfully transformed 3 identities

📤 Uploading 3 identities in 1 batch(es)...
🔍 DRY RUN MODE - No actual uploads will be performed

📦 Batch 1/1 (3 identities)...
🔍 DRY RUN - Would POST to: https://api.split.io/internal/api/v2/trafficTypes/user/environments/prod-environment-id/identities
📦 Payload sample (first 2 identities):
[
  {
    "key": "alice@example.com",
    "values": {
      "company_name": "Acme Corp",
      "org_pin": "1234",
      "account_tier": "premium"
    }
  },
  {
    "key": "bob@example.com",
    "values": {
      "company_name": "Widget Inc",
      "org_pin": "5678",
      "account_tier": "free"
    }
  }
]
```

### Step 4: Upload for Real

```bash
python3 scripts/fme_identities_utils/fme_bulk_identities.py \
    --csv my_identities.csv \
    --config config/fme_identities.json
```

**Expected output:**
```
📖 Loading config from: config/fme_identities.json
📖 Loading CSV from: my_identities.csv
📊 Found 3 rows in CSV
🔄 Transforming CSV rows to Split identities...
✅ Successfully transformed 3 identities

📤 Uploading 3 identities in 1 batch(es)...

📦 Batch 1/1 (3 identities)...
✅ Successfully uploaded 3 identities

============================================================
📊 UPLOAD SUMMARY
============================================================
Total rows in CSV:       3
Valid identities:        3
Transformation errors:   0
Successfully uploaded:   3
Failed to upload:        0
```

## Troubleshooting

### "CSV must have a 'key' column"

Your CSV is missing the required `key` column. Add it as the first column:

```csv
key,attr1,attr2
user1,value1,value2
```

### "Missing required config fields"

Your config JSON is missing required fields. Ensure all of these exist:
- `api_base_url`
- `traffic_type_id`
- `environment_id`
- `admin_api_key`
- `attribute_mapping`

### HTTP 401 Unauthorized

Your Admin API key is invalid or expired. Generate a new one in FME:
1. Go to FME Settings → API Keys
2. Create new Admin API key
3. Update `admin_api_key` in config

### HTTP 404 Not Found

Check your `traffic_type_id` or `environment_id`:
1. Verify traffic type exists in FME Settings
2. Verify environment ID is correct (not the environment name)
3. Environment ID format: looks like `abc123-def456-ghi789`

### Attribute Not Found / Invalid Attribute ID

The attribute doesn't exist in FME. Create it first:
1. Go to FME Settings > Projects > View > Traffic Types > View / Edit attributes
2. Create the attribute with the exact ID from your config
3. Attribute IDs are case-sensitive

### "Row X had errors"

Check the CSV row for:
- Missing `key` value
- Malformed data
- Special characters that need escaping

Run with `--dry-run` to see which rows fail before uploading.

## Advanced Usage

### Multiple Environments

Upload to different environments using separate configs:

```bash
# Production
python3 scripts/fme_identities_utils/fme_bulk_identities.py \
    --csv identities.csv \
    --config config/fme_prod.json

# Staging
python3 scripts/fme_identities_utils/fme_bulk_identities.py \
    --csv identities.csv \
    --config config/fme_staging.json
```

### Partial Attribute Updates (Use Patch Mode!)

To update only specific attributes without affecting others, use `--patch-mode`:

```csv
key,plan
user_001,premium
user_002,enterprise
```

```bash
python3 scripts/fme_identities_utils/fme_bulk_identities.py \
    --csv plan_updates.csv \
    --config config/fme_identities.json \
    --patch-mode
```

This updates only the `plan` attribute, **preserving** all other existing attributes like email, country, etc.

**Without `--patch-mode`**, this would **DELETE** all other attributes!

### Large Datasets

For millions of identities:

1. Use smaller batch sizes to avoid timeouts:
   ```bash
   --batch-size 500
   ```

2. Split CSV into chunks if needed:
   ```bash
   split -l 10000 identities.csv chunk_
   ```

3. Monitor progress - the tool shows batch-by-batch status

## API Reference

### Bulk Endpoint (Default Mode)

**Method:** `POST`
**URL:** `/internal/api/v2/trafficTypes/{traffic-type-id}/environments/{environment-id}/identities`

**Payload Format:**
```json
[
  {
    "key": "user_123",
    "values": {
      "attribute_id_1": "value1",
      "attribute_id_2": "value2"
    }
  },
  {
    "key": "user_456",
    "values": {
      "attribute_id_1": "value3"
    }
  }
]
```

**Behavior:**
- ✅ Creates new identities if they don't exist
- ⚠️ **OVERWRITES all attributes** for existing identities (deletes unspecified attributes)
- Fast batched uploads
- Changes processed asynchronously (may take up to 1 minute for large traffic types)

**Docs:** https://docs.split.io/reference/save-identities

---

### Single Identity Endpoint (Patch Mode)

**Method:** `PUT`
**URL:** `/internal/api/v2/trafficTypes/{traffic-type-id}/environments/{environment-id}/identities/{key}`

**Payload Format:**
```json
{
  "values": {
    "attribute_id_1": "value1",
    "attribute_id_2": "value2"
  }
}
```

**Behavior:**
- ✅ Creates new identity if it doesn't exist
- ✅ **Updates only provided attributes**, preserves existing attributes
- Slower (one API call per identity)
- Ideal for partial updates

**Docs:** https://docs.split.io/reference/update-identity

## Security Notes

⚠️ **NEVER commit your config file with real API keys!**

Add to `.gitignore`:
```
config/fme_identities.json
config/fme_*.json
*.csv
```

Use environment variables for CI/CD:
```bash
export SPLIT_API_KEY="your-key"
# Then reference in config: "${SPLIT_API_KEY}"
```

## Support

**Questions about this tool?**
- Check this README
- Review example files in `scripts/`

**FME API questions?**
- Docs: https://docs.split.io/reference/identities-overview
- Support: Contact FME support

**Issues with pmClaude repo?**
- File an issue in the repo
- Check `README.md` for repo guidelines
